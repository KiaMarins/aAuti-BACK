import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Produto } from './produto.entity';

@Injectable()
export class ProductService {
  constructor(
    @InjectRepository(Produto)
    private userRepository: Repository<Produto>,
  ) {}

  async findAll(): Promise<Produto[]> {
    return this.userRepository.find();
  }

  async findOne(id: number): Promise<Produto> {
    return this.userRepository.findOneBy({ id });
  }

  async create(user: Produto): Promise<Produto> {
    return this.userRepository.save(user);
  }

  async update(id: number, user: Partial<Produto>): Promise<Produto> {
    await this.userRepository.update(id, user);
    return this.userRepository.findOneBy({ id });
  }

  async remove(id: number): Promise<void> {
    await this.userRepository.delete(id);
  }
}