import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class produto {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  nome: string;

  @Column()
  valor: number;

}