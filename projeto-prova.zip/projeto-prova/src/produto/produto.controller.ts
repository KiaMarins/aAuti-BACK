import { Controller, Get, Post, Body, Param, Delete, Put } from '@nestjs/common';
import { ProdutoService } from './produto.service';
import { Produto } from './produto.entity';

@Controller('product')
export class ProductController {
  constructor(private readonly userService: ProdutoService) {}

  @Get()
  async findAll(): Promise<Produto[]> {
    return this.userService.findAll();
  }

  @Get(':id')
  async findOne(@Param('id') id: number): Promise<Produto> {
    return this.userService.findOne(id);
  }

  @Post()
  async create(@Body() user: Produto): Promise<Produto> {
    return this.userService.create(user);
  }

  @Put(':id')
  async update(@Param('id') id: number, @Body() user: Partial<Produto>): Promise<Produto> {
    return this.userService.update(id, user);
  }

  @Delete(':id')
  async remove(@Param('id') id: number): Promise<void> {
    return this.userService.remove(id);
  }
}